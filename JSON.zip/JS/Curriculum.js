document.addEventListener("DOMContentLoaded", async () => {
  console.log("Curriculum.js: Initializing...")

  // Check if we're on mobile
  checkMobileState()

  // Add resize listener for responsive adjustments
  window.addEventListener("resize", handleResize)

  // Initialize the section structure first
  initializeSections()

  // Add mobile-specific styles
  if (STATE.isMobile) {
    applyMobileStyles()
  }

  // Show loading state
  showLoading(true)

  try {
    // Load categories data first
    await loadCategoriesData()

    // Then load curriculum data
    await loadCurriculumData()

    // Render all sections with the loaded data
    renderAllSections()

    // Add animation to cards
    animateCards()

    // Hide loading state
    showLoading(false)
  } catch (error) {
    console.error("Curriculum.js: Error during initialization:", error)
    showError("Si è verificato un errore durante l'inizializzazione: " + error.message)
  }
})

// Configuration
const CONFIG = {
  jsonPath: "JSON/Curriculum.json",
  categoriesJsonPath: "JSON/categories.json",
  fallbackJsonPath: "JSON/Curriculum.json", // Fallback in case of typo in filename
  animationDuration: 500,
  animationDelay: 100,
  defaultOpenSection: 2, // Index of section to open by default (2 = Esperienze Lavorative)
  debugMode: true,
  // Mobile configuration
  mobileBreakpoint: 768,
  siteImageMaxHeight: 120, // Smaller site images for better visibility
  removeScrollableContainers: true, // Remove scrollable containers for better UX
}

// State management
const STATE = {
  curriculumData: null,
  categoriesData: null,
  expandedSections: {},
  categorizedSkills: null,
  isLoading: true,
  hasError: false,
  errorMessage: "",
  isMobile: window.innerWidth <= CONFIG.mobileBreakpoint,
}

// DOM Elements cache
const DOM = {}

/**
 * Check if we're on mobile and update state
 */
function checkMobileState() {
  STATE.isMobile = window.innerWidth <= CONFIG.mobileBreakpoint
  console.log(`Curriculum.js: Device detected as ${STATE.isMobile ? "mobile" : "desktop"}`)
}

/**
 * Handle window resize events
 */
function handleResize() {
  const wasMobile = STATE.isMobile
  checkMobileState()

  // If we crossed the mobile breakpoint, apply or remove mobile styles
  if (wasMobile !== STATE.isMobile) {
    if (STATE.isMobile) {
      applyMobileStyles()
    } else {
      removeMobileStyles()
    }

    // Re-render sections that need responsive adjustments
    if (STATE.curriculumData) {
      renderWebSite(STATE.curriculumData.sites)

      // Re-render competenze section for better mobile experience
      if (STATE.categorizedSkills) {
        renderCompetenze(STATE.curriculumData.competenze)
      }

      // Re-render esperienze section for better mobile experience
      if (STATE.curriculumData.esperienze) {
        renderEsperienze(STATE.curriculumData.esperienze)
      }
    }
  }
}

/**
 * Apply mobile-specific styles
 */
function applyMobileStyles() {
  // Center curriculum title on mobile
  const sectionTitle = document.querySelector("#curriculum .section-title")
  if (sectionTitle) {
    sectionTitle.style.textAlign = "center"
    sectionTitle.style.width = "100%"
    sectionTitle.style.left = "auto"
    sectionTitle.style.transform = "none"
  }

  // Remove scrollable containers if configured
  if (CONFIG.removeScrollableContainers) {
    document.querySelectorAll(".card-container").forEach((container) => {
      container.style.maxHeight = "none"
      container.style.overflowY = "visible"
    })
  }

  // Adjust skill tabs for better mobile experience
  document.querySelectorAll(".skill-tab").forEach((tab) => {
    tab.style.width = STATE.isMobile ? "calc(50% - 0.4rem)" : ""
    tab.style.justifyContent = STATE.isMobile ? "center" : ""
  })

  // Adjust role badges for better mobile experience
  document.querySelectorAll(".role-badge").forEach((badge) => {
    badge.style.margin = STATE.isMobile ? "0.3rem" : ""
    badge.style.display = STATE.isMobile ? "inline-block" : ""
  })
}

/**
 * Remove mobile-specific styles
 */
function removeMobileStyles() {
  // Restore curriculum title styles
  const sectionTitle = document.querySelector("#curriculum .section-title")
  if (sectionTitle) {
    sectionTitle.style.textAlign = ""
    sectionTitle.style.width = ""
    sectionTitle.style.left = ""
    sectionTitle.style.transform = ""
  }

  // Restore scrollable containers if they were removed
  if (CONFIG.removeScrollableContainers) {
    document.querySelectorAll(".card-container").forEach((container) => {
      container.style.maxHeight = ""
      container.style.overflowY = ""
    })
  }

  // Reset skill tabs for desktop experience
  document.querySelectorAll(".skill-tab").forEach((tab) => {
    tab.style.width = ""
    tab.style.justifyContent = ""
  })

  // Reset role badges for desktop experience
  document.querySelectorAll(".role-badge").forEach((badge) => {
    badge.style.margin = ""
    badge.style.display = ""
  })
}

/**
 * Initialize the section structure in the DOM
 */
function initializeSections() {
  const sectionContainer = document.getElementById("sectiion")
  if (!sectionContainer) {
    console.error("Curriculum.js: Section container 'sectiion' not found!")
    return
  }

  // Ogni bottone corrisponde alla propria sezione dedicata: cliccando un
  // bottone si vede SOLO quel contenuto (tab), non tutte le sezioni
  // impilate una sotto l'altra.
  const parts = [
    { id: "attestati", icon: "bx-medal", label: "Attestati" },
    { id: "linguistiche", icon: "bx-globe", label: "Competenze Linguistiche" },
    { id: "esperienze", icon: "bx-briefcase", label: "Esperienze Lavorative" },
    { id: "istruzione", icon: "bx-book", label: "Istruzione" },
    { id: "competenze", icon: "bx-code-block", label: "Competenze" },
    { id: "sites", icon: "bx-laptop", label: "Siti Web" },
  ]

  STATE.currTabs = parts

  const quickNav = document.getElementById("curriculumQuickNav")
  if (quickNav) {
    quickNav.innerHTML = parts
      .map(
        (part, index) =>
          `<button type="button" class="curr-nav-pill${index === 0 ? " active" : ""}" data-target="${part.id}">
            <i class='bx ${part.icon}'></i><span>${part.label}</span>
          </button>`
      )
      .join("")

    quickNav.querySelectorAll(".curr-nav-pill").forEach((pill) => {
      pill.addEventListener("click", () => {
        activateCurrTab(pill.dataset.target)
      })
    })
  }

  sectionContainer.innerHTML = parts
    .map(
      (part, index) => `
    <div id="${part.id}" class="section curr-block${index === 0 ? " active-tab" : ""}">
      <h3><i class='bx ${part.icon}'></i> ${part.label}</h3>
      <div class="card-container">
      </div>
    </div>`
    )
    .join("")

  // Cache DOM elements for later use
  DOM.sections = {
    attestati: document.querySelector("#attestati .card-container"),
    linguistiche: document.querySelector("#linguistiche .card-container"),
    esperienze: document.querySelector("#esperienze .card-container"),
    istruzione: document.querySelector("#istruzione .card-container"),
    competenze: document.querySelector("#competenze .card-container"),
    sites: document.querySelector("#sites .card-container"),
  }
}

/**
 * Attiva la scheda (tab) del curriculum corrispondente a targetId:
 * mostra solo quella sezione e nasconde tutte le altre, aggiornando
 * anche lo stato attivo dei bottoni di navigazione.
 */
function activateCurrTab(targetId) {
  if (!STATE.currTabs || !STATE.currTabs.some((part) => part.id === targetId)) return

  document.querySelectorAll("#curriculum .curr-block").forEach((block) => {
    const isTarget = block.id === targetId
    block.classList.toggle("active-tab", isTarget)
    if (isTarget) {
      const cardContainer = block.querySelector(".card-container")
      if (cardContainer) {
        animateCardsInSection(cardContainer)
      }
    }
  })

  document.querySelectorAll(".curr-nav-pill").forEach((pill) => {
    pill.classList.toggle("active", pill.dataset.target === targetId)
  })

  setTimeout(() => {
    initializeSkillAnimations()
  }, 150)

  const header = document.querySelector("header")
  const headerOffset = header ? header.offsetHeight + 16 : 16
  const section = document.getElementById("curriculum")
  if (section) {
    const targetY = section.getBoundingClientRect().top + window.scrollY - headerOffset
    window.scrollTo({ top: targetY, behavior: "smooth" })
  }
}

/**
 * Animate cards in a section
 */
function animateCardsInSection(container) {
  if (!container) return

  const cards = container.querySelectorAll(".card")
  cards.forEach((card, index) => {
    card.style.opacity = "0"
    card.style.transform = "translateY(50px)"

    setTimeout(
      () => {
        card.style.opacity = "1"
        card.style.transform = "translateY(0)"
      },
      100 + index * 50,
    )
  })
}

/**
 * Animate all cards
 */
function animateCards() {
  const cards = document.querySelectorAll(".card")
  cards.forEach((card, index) => {
    card.style.setProperty("--i", (index % 5) + 1)
    card.classList.add("animated")
  })
}

/**
 * Initialize skill progress bar animations
 */
function initializeSkillAnimations() {
  const progressBars = document.querySelectorAll(".progress-bar")
  if (!progressBars || progressBars.length === 0) {
    console.log("Curriculum.js: No progress bars found to animate")
    return
  }

  console.log(`Curriculum.js: Initializing animations for ${progressBars.length} progress bars`)

  progressBars.forEach((bar) => {
    const progress = bar.getAttribute("data-progress") || "75"
    const fill = bar.querySelector(".progress-fill")

    if (fill) {
      // Reset first
      fill.style.width = "0%"

      // Animate after a short delay
      setTimeout(() => {
        fill.style.width = `${progress}%`
      }, 100)
    }
  })
}

/**
 * Show loading state
 */
function showLoading(isLoading) {
  STATE.isLoading = isLoading

  // You could add a loading spinner here if needed
  if (isLoading) {
    console.log("Curriculum.js: Loading...")
  } else {
    console.log("Curriculum.js: Loading complete")
  }
}

/**
 * Show error message
 */
function showError(message) {
  STATE.hasError = true
  STATE.errorMessage = message

  const curriculumSection = document.getElementById("curriculum")
  if (!curriculumSection) return

  const container = curriculumSection.querySelector(".container")
  if (!container) return

  const errorDiv = document.createElement("div")
  errorDiv.className = "error-message"
  errorDiv.innerHTML = `
    <i class='bx bx-error-circle'></i>
    <p>${message}</p>
    <button onclick="location.reload()" class="reload-btn">
      <i class='bx bx-refresh'></i> Ricarica
    </button>
  `

  container.appendChild(errorDiv)
}

/**
 * Load categories data from JSON file
 */
async function loadCategoriesData() {
  try {
    console.log(`Curriculum.js: Attempting to load categories from ${CONFIG.categoriesJsonPath}`)
    const response = await fetch(CONFIG.categoriesJsonPath)

    if (!response.ok) {
      console.warn(`Curriculum.js: Failed to load categories from ${CONFIG.categoriesJsonPath}`)
      // Use hardcoded categories as fallback
      STATE.categoriesData = {
        skillCategories: {
          Programmazione: ["C", "C#", "C++", "Python", "JavaScript", "HTML5", "CSS3", "React JS", "Node.js", "Vite"],
          "DevOps & Tools": ["Git", "VS Code", "Docker", "PostgreSQL", "Linux", "Windows"],
          "IoT & Protocolli": ["MQTT", "AMQP", "CoAP", "HTTP", "OPC-UA", "Raspberry Pi", "Node-RED"],
          Visualizzazione: ["Mermaid", "Chart.js", "MathJax"],
        },
        defaultProjectTags: ["HTML", "CSS", "JavaScript", "Responsive", "Frontend", "UI/UX"],
      }
    } else {
      STATE.categoriesData = await response.json()
      console.log("Curriculum.js: Categories data loaded successfully")
    }

    return STATE.categoriesData
  } catch (error) {
    console.error("Curriculum.js: Error loading categories data:", error)

    // Use hardcoded categories as fallback
    STATE.categoriesData = {
      skillCategories: {
        Programmazione: ["C", "C#", "C++", "Python", "JavaScript", "HTML5", "CSS3", "React JS", "Node.js", "Vite"],
        "DevOps & Tools": ["Git", "VS Code", "Docker", "PostgreSQL", "Linux", "Windows"],
        "IoT & Protocolli": ["MQTT", "AMQP", "CoAP", "HTTP", "OPC-UA", "Raspberry Pi", "Node-RED"],
        Visualizzazione: ["Mermaid", "Chart.js", "MathJax"],
      },
      defaultProjectTags: ["HTML", "CSS", "JavaScript", "Responsive", "Frontend", "UI/UX"],
    }
  }
}

/**
 * Load curriculum data from JSON file
 */
async function loadCurriculumData() {
  try {
    console.log(`Curriculum.js: Attempting to load data from ${CONFIG.jsonPath}`)
    const response = await fetch(CONFIG.jsonPath)

    if (!response.ok) {
      console.warn(`Curriculum.js: Failed to load from ${CONFIG.jsonPath}, trying fallback...`)
      // Try fallback path
      const fallbackResponse = await fetch(CONFIG.fallbackJsonPath)

      if (!fallbackResponse.ok) {
        throw new Error(`Failed to load data: ${response.status} ${response.statusText}`)
      }

      STATE.curriculumData = await fallbackResponse.json()
      console.log("Curriculum.js: Data loaded from fallback path successfully")
    } else {
      STATE.curriculumData = await response.json()
      console.log("Curriculum.js: Data loaded successfully")
    }

    // Categorize skills based on JSON data
    if (STATE.curriculumData.competenze) {
      STATE.categorizedSkills = categorizeSkillsFromJson(STATE.curriculumData.competenze)
    }

    return STATE.curriculumData
  } catch (error) {
    console.error("Curriculum.js: Error loading data:", error)
    STATE.hasError = true
    STATE.errorMessage = error.message

    // Load fallback data
    STATE.curriculumData = generateFallbackData()
    STATE.categorizedSkills = categorizeSkillsFromJson(STATE.curriculumData.competenze)

    throw error
  }
}

/**
 * Render all sections with the loaded data
 */
function renderAllSections() {
  if (!STATE.curriculumData) {
    console.error("Curriculum.js: No data available to render")
    return
  }

  console.log("Curriculum.js: Rendering all sections")

  // Render each section
  renderAttestati(STATE.curriculumData.attestati)
  renderLinguistiche(STATE.curriculumData.linguistiche)
  renderEsperienze(STATE.curriculumData.esperienze)
  renderIstruzione(STATE.curriculumData.istruzione)
  renderCompetenze(STATE.curriculumData.competenze)
  renderWebSite(STATE.curriculumData.sites)

  // Anima solo la scheda attiva all'apertura (le altre sono nascoste finché
  // non vengono selezionate con i bottoni sopra)
  const activeBlock = document.querySelector("#curriculum .curr-block.active-tab")
  if (activeBlock) {
    activeBlock.style.opacity = "1"
    activeBlock.style.transform = "translateY(0)"
    const cardContainer = activeBlock.querySelector(".card-container")
    if (cardContainer) {
      animateCardsInSection(cardContainer)
    }
  }

  // Le barre di progresso delle competenze si animano quando quella scheda viene aperta
  setTimeout(() => {
    initializeSkillAnimations()
  }, 300)
}

/**
 * Render attestati section
 */
function renderAttestati(attestati) {
  if (!attestati || !Array.isArray(attestati) || !DOM.sections.attestati) {
    console.warn("Curriculum.js: Invalid attestati data or container not found")
    return
  }

  DOM.sections.attestati.innerHTML = ""

  const stickyControls = document.createElement("div")
  stickyControls.className = "skills-sticky-controls"

  const searchBar = document.createElement("div")
  searchBar.className = "year-filter-bar"

  const cardsContainer = document.createElement("div")
  cardsContainer.className = "attestati-list"

  let searchTerm = ""

  const renderAttestatiCards = (items) => {
    cardsContainer.innerHTML = ""

    if (!items || items.length === 0) {
      cardsContainer.innerHTML = `
        <div class="empty-filter-message">
          <i class='bx bx-info-circle'></i>
          <p>Non ci sono attestati per questi criteri.</p>
        </div>
      `
      return
    }

    items.forEach((attestato, index) => {
      const card = document.createElement("div")
      card.className = "card"
      card.setAttribute("data-aos", "fade-up")
      card.setAttribute("data-aos-delay", (index * 100).toString())

      let html = `
        <div class="card-header">
          <div class="certificate-icon">
            <i class='bx bx-certification'></i>
          </div>
          <h4>${attestato.titolo || "Titolo non disponibile"}</h4>
        </div>
        <div class="card-body">
          <p>${attestato.descrizione || "Descrizione non disponibile"}</p>
        </div>
      `

      if (attestato.certificato) {
        html += `
          <div class="card-footer">
            <a href="${attestato.certificato}" class="testo" download>
              <span>Scarica Certificato</span>
              <i class='bx bx-download'></i>
            </a>
          </div>
        `
      }

      card.innerHTML = html
      cardsContainer.appendChild(card)
    })
  }

  const applyAttestatiFilters = () => {
    const normalizedSearch = searchTerm.trim().toLowerCase()
    let filtered = attestati

    if (normalizedSearch) {
      filtered = filtered.filter((item) => {
        const title = (item?.titolo || "").toLowerCase()
        const description = (item?.descrizione || "").toLowerCase()
        return title.includes(normalizedSearch) || description.includes(normalizedSearch)
      })
    }

    cardsContainer.classList.add("fade-out")
    setTimeout(() => {
      renderAttestatiCards(filtered)
      cardsContainer.classList.remove("fade-out")
      cardsContainer.scrollTop = 0
    }, 250)
  }

  searchBar.innerHTML = `
    <label>
      <span>Cerca</span>
      <input
        type="search"
        class="year-input attestati-search-input"
        placeholder="Es. sicurezza, GDPR, certificato..."
      />
    </label>
    <button type="button" class="year-reset-btn attestati-search-reset">Reset</button>
  `

  const searchInput = searchBar.querySelector(".attestati-search-input")
  const resetButton = searchBar.querySelector(".attestati-search-reset")

  const updateSearch = () => {
    searchTerm = searchInput.value || ""
    applyAttestatiFilters()
  }

  searchInput.addEventListener("input", updateSearch)
  searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault()
      updateSearch()
    }
  })

  resetButton.addEventListener("click", () => {
    searchInput.value = ""
    searchTerm = ""
    applyAttestatiFilters()
  })

  stickyControls.appendChild(searchBar)
  DOM.sections.attestati.appendChild(stickyControls)
  DOM.sections.attestati.appendChild(cardsContainer)
  applyAttestatiFilters()
}

/**
 * Render competenze linguistiche section
 */
function renderLinguistiche(linguistiche) {
  if (!linguistiche || !Array.isArray(linguistiche) || !DOM.sections.linguistiche) {
    console.warn("Curriculum.js: Invalid linguistiche data or container not found")
    return
  }

  DOM.sections.linguistiche.innerHTML = ""

  const levels = [...new Set(linguistiche.map((item) => (item.livello || "").trim()).filter(Boolean))]
  const filters = ["Tutti", ...levels]

  const stickyControls = document.createElement("div")
  stickyControls.className = "skills-sticky-controls"

  const tabsContainer = document.createElement("div")
  tabsContainer.className = "skills-tabs"

  const searchBar = document.createElement("div")
  searchBar.className = "year-filter-bar"

  const cardsContainer = document.createElement("div")
  cardsContainer.className = "linguistiche-list"

  let activeLevels = new Set()
  let searchTerm = ""

  const renderLinguisticheCards = (items) => {
    cardsContainer.innerHTML = ""

    if (!items || items.length === 0) {
      cardsContainer.innerHTML = `
        <div class="empty-filter-message">
          <i class='bx bx-info-circle'></i>
          <p>Non ci sono lingue per questi criteri.</p>
        </div>
      `
      return
    }

    items.forEach((lingua, index) => {
      const card = document.createElement("div")
      card.className = "card language-card"
      card.setAttribute("data-aos", "zoom-in")
      card.setAttribute("data-aos-delay", (index * 100).toString())

      const levelIndicator = createLevelIndicator(lingua.livello)
      const imgSrc = lingua.immagine || "/placeholder.svg?height=100&width=100"

      card.innerHTML = `
        <div class="language-flag">
          <img src="${imgSrc}" alt="Bandiera ${
            lingua.lingua
          }" onerror="this.src='/placeholder.svg?height=100&width=100'; this.onerror=null;" />
        </div>
        <h4>${lingua.lingua || "Lingua non specificata"}</h4>
        <div class="language-level">
          <strong>Livello:</strong> ${lingua.livello || "Non specificato"}
        </div>
        <div class="level-indicator">
          ${levelIndicator}
        </div>
        ${
          lingua.link
            ? `
          <button class="go-live-btn" onclick="window.open('${lingua.link}', '_blank')">
            <span>Impara la lingua</span>
            <i class='bx bx-book-open'></i>
          </button>
        `
            : ""
        }
      `

      cardsContainer.appendChild(card)
    })
  }

  const applyLinguisticheFilters = () => {
    const normalizedSearch = searchTerm.trim().toLowerCase()
    let filtered = linguistiche

    if (activeLevels.size > 0) {
      filtered = filtered.filter((item) => activeLevels.has((item.livello || "").trim()))
    }

    if (normalizedSearch) {
      filtered = filtered.filter((item) => {
        const language = (item?.lingua || "").toLowerCase()
        const level = (item?.livello || "").toLowerCase()
        return language.includes(normalizedSearch) || level.includes(normalizedSearch)
      })
    }

    cardsContainer.classList.add("fade-out")
    setTimeout(() => {
      renderLinguisticheCards(filtered)
      cardsContainer.classList.remove("fade-out")
      cardsContainer.scrollTop = 0
    }, 250)
  }

  const updateActiveTabs = () => {
    tabsContainer.querySelectorAll(".skill-tab").forEach((tab) => {
      const tabFilter = tab.getAttribute("data-filter")
      tab.classList.toggle("active", tabFilter === "Tutti" ? activeLevels.size === 0 : activeLevels.has(tabFilter))
    })
  }

  buildFilterSelect(tabsContainer, filters, activeLevels, applyLinguisticheFilters)

  searchBar.innerHTML = `
    <label>
      <span>Cerca</span>
      <input
        type="search"
        class="year-input linguistiche-search-input"
        placeholder="Es. inglese, italiano, A2, C1..."
      />
    </label>
    <button type="button" class="year-reset-btn linguistiche-search-reset">Reset</button>
  `

  const searchInput = searchBar.querySelector(".linguistiche-search-input")
  const resetButton = searchBar.querySelector(".linguistiche-search-reset")

  const updateSearch = () => {
    searchTerm = searchInput.value || ""
    applyLinguisticheFilters()
  }

  searchInput.addEventListener("input", updateSearch)
  searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault()
      updateSearch()
    }
  })

  resetButton.addEventListener("click", () => {
    searchInput.value = ""
    searchTerm = ""
    applyLinguisticheFilters()
  })

  stickyControls.appendChild(tabsContainer)
  stickyControls.appendChild(searchBar)
  DOM.sections.linguistiche.appendChild(stickyControls)
  DOM.sections.linguistiche.appendChild(cardsContainer)
  updateActiveTabs()
  applyLinguisticheFilters()
}

/**
 * Create visual language level indicator
 */
function createLevelIndicator(level) {
  const levels = {
    A1: 1,
    A2: 2,
    B1: 3,
    B2: 4,
    C1: 5,
    C2: 6,
    Madrelingua: 6,
  }

  const levelValue = levels[level] || 0
  let indicators = ""

  for (let i = 1; i <= 6; i++) {
    const active = i <= levelValue ? "active" : ""
    indicators += `<div class="level-dot ${active}" data-level="${i}"></div>`
  }

  return `
    <div class="level-dots">
      ${indicators}
    </div>
    <div class="level-labels">
      <span>A1</span>
      <span>A2</span>
      <span>B1</span>
      <span>B2</span>
      <span>C1</span>
      <span>C2</span>
    </div>
  `
}

/**
 * Scroll to the top of a curriculum section
 */
function scrollToSectionTop(element) {
  const section = element?.closest(".section")
  if (!section) return

  const header = document.querySelector("header")
  const headerOffset = header ? header.offsetHeight + 16 : 16
  const targetY = section.getBoundingClientRect().top + window.scrollY - headerOffset

  window.scrollTo({
    top: targetY,
    behavior: "smooth",
  })
}

/**
 * Costruisce un menu a tendina (select) per i filtri generati dai dati
 * (es. Livello 5 EQF, Madrelingua, Stage Curricolare...), al posto delle
 * pillole cliccabili: più compatto e comodo su mobile.
 * `activeLevels` è lo stesso Set già usato dai filtri esistenti: quando si
 * sceglie "Tutti" viene svuotato, altrimenti contiene solo il valore scelto.
 */
function buildFilterSelect(tabsContainer, filters, activeLevels, onChange) {
  tabsContainer.classList.add("skills-select-wrap")
  tabsContainer.innerHTML = `
    <label class="skill-select-label">
      <i class='bx bx-filter-alt'></i>
      <select class="skill-select"></select>
    </label>
  `
  const select = tabsContainer.querySelector(".skill-select")
  filters.forEach((filter) => {
    const option = document.createElement("option")
    option.value = filter
    option.textContent = filter
    select.appendChild(option)
  })

  select.addEventListener("change", () => {
    activeLevels.clear()
    if (select.value !== "Tutti") {
      activeLevels.add(select.value)
    }
    onChange()
    scrollToSectionTop(tabsContainer)
  })

  return select
}

/**
 * Resolve category label for a skill using categorized data
 */
function getSkillCategoryLabel(skill) {
  if (!STATE.categorizedSkills) return "Altro"

  const skillName = (skill?.nome || "").trim()
  if (!skillName) return "Altro"

  const foundCategory = Object.keys(STATE.categorizedSkills).find((category) =>
    (STATE.categorizedSkills[category] || []).some((item) => (item.nome || "").trim() === skillName),
  )

  return foundCategory || "Altro"
}

/**
 * Parse a date token and return month/year.
 * Supports: dd/mm/yyyy, mm/yyyy, yyyy.
 */
function parseMonthYearToken(token) {
  if (!token) return null
  const cleanToken = String(token).trim()

  const dayMonthYear = cleanToken.match(/^(\d{1,2})\/(\d{1,2})\/((?:19|20)\d{2})$/)
  if (dayMonthYear) {
    const month = Number.parseInt(dayMonthYear[2], 10)
    const year = Number.parseInt(dayMonthYear[3], 10)
    if (month >= 1 && month <= 12) return { month, year }
  }

  const monthYear = cleanToken.match(/^(\d{1,2})\/((?:19|20)\d{2})$/)
  if (monthYear) {
    const month = Number.parseInt(monthYear[1], 10)
    const year = Number.parseInt(monthYear[2], 10)
    if (month >= 1 && month <= 12) return { month, year }
  }

  const yearOnly = cleanToken.match(/^((?:19|20)\d{2})$/)
  if (yearOnly) {
    const year = Number.parseInt(yearOnly[1], 10)
    return { month: 1, year }
  }

  return null
}

/**
 * Convert month/year to comparable numeric value
 */
function monthYearToValue(month, year) {
  return year * 12 + (month - 1)
}

/**
 * Extract start/end month-year values from an item period string
 */
function getItemMonthSpan(item) {
  const now = new Date()
  const currentMonth = now.getMonth() + 1
  const currentYear = now.getFullYear()
  const periodText = String(item?.periodo || "")
  const normalizedPeriod = periodText.replace(/[–—]/g, "-")

  const matches = [...normalizedPeriod.matchAll(/(\d{1,2}\/\d{1,2}\/(?:19|20)\d{2}|\d{1,2}\/(?:19|20)\d{2}|(?:19|20)\d{2})/g)]
  const points = matches.map((match) => parseMonthYearToken(match[1])).filter(Boolean)

  if (points.length === 0) return null

  const values = points.map((point) => monthYearToValue(point.month, point.year))
  let startValue = Math.min(...values)
  let endValue = Math.max(...values)

  if (/ora|presente|present/i.test(periodText)) {
    endValue = monthYearToValue(currentMonth, currentYear)
  }

  if (endValue < startValue) {
    const temp = startValue
    startValue = endValue
    endValue = temp
  }

  return { startValue, endValue }
}

/**
 * Parse MM/YYYY text input
 */
function parseMonthYearInput(inputText) {
  if (!inputText) return null
  const text = String(inputText).trim()
  if (!text) return null
  const parsed = parseMonthYearToken(text)
  if (!parsed) return null
  return monthYearToValue(parsed.month, parsed.year)
}

/**
 * Format a month/year value as MM/YYYY
 */
function formatMonthYearValue(value) {
  if (typeof value !== "number" || Number.isNaN(value)) return ""
  const year = Math.floor(value / 12)
  const month = (value % 12) + 1
  return `${String(month).padStart(2, "0")}/${year}`
}

/**
 * Format free user typing to MM/YYYY while typing
 */
function normalizeMonthYearTyping(rawValue) {
  const digitsOnly = String(rawValue || "").replace(/\D/g, "").slice(0, 6)
  if (digitsOnly.length <= 2) return digitsOnly
  return `${digitsOnly.slice(0, 2)}/${digitsOnly.slice(2)}`
}

/**
 * Check if item period overlaps selected month/year range
 */
function isItemInMonthRange(item, fromValue, toValue) {
  if (fromValue === null && toValue === null) return true

  const span = getItemMonthSpan(item)
  if (!span) return false

  const selectedFrom = fromValue === null ? span.startValue : fromValue
  const selectedTo = toValue === null ? span.endValue : toValue

  return span.startValue <= selectedTo && span.endValue >= selectedFrom
}

/**
 * Render esperienze lavorative section with improved layout
 */
function renderEsperienze(esperienze) {
  if (!esperienze || !Array.isArray(esperienze) || !DOM.sections.esperienze) {
    console.warn("Curriculum.js: Invalid esperienze data or container not found")
    return
  }

  DOM.sections.esperienze.innerHTML = ""

  const roles = [...new Set(esperienze.map((item) => (item.ruolo || "").trim()).filter(Boolean))]
  const filters = ["Tutti", ...roles]

  const tabsContainer = document.createElement("div")
  tabsContainer.className = "skills-tabs"

  const yearsBar = document.createElement("div")
  yearsBar.className = "year-filter-bar"
  const searchBar = document.createElement("div")
  searchBar.className = "year-filter-bar"

  const cardsContainer = document.createElement("div")
  cardsContainer.className = "experience-list"

  const availableMonthValues = esperienze
    .map((item) => getItemMonthSpan(item))
    .filter(Boolean)
    .flatMap((span) => [span.startValue, span.endValue])

  const now = new Date()
  const fallbackMonthValue = monthYearToValue(now.getMonth() + 1, now.getFullYear())
  const minMonthValue = availableMonthValues.length ? Math.min(...availableMonthValues) : fallbackMonthValue
  const maxMonthValue = availableMonthValues.length ? Math.max(...availableMonthValues) : fallbackMonthValue

  let activeRoles = new Set()
  let fromMonthValue = null
  let toMonthValue = null
  let searchTerm = ""

  const renderEsperienzeCards = (items) => {
    cardsContainer.innerHTML = ""

    if (!items || items.length === 0) {
      cardsContainer.innerHTML = `
        <div class="empty-filter-message">
          <i class='bx bx-info-circle'></i>
          <p>Non ci sono dati per questi criteri.</p>
        </div>
      `
      return
    }

    items.forEach((esperienza, index) => {
      const card = document.createElement("div")
      card.className = "card experience-card"
      card.setAttribute("data-aos", index % 2 === 0 ? "fade-right" : "fade-left")
      card.setAttribute("data-aos-delay", (index * 150).toString())

      const attivitaList = Array.isArray(esperienza.attivita)
        ? esperienza.attivita.map((attivita) => `<li><i class='bx bx-check'></i> ${attivita}</li>`).join("")
        : "<li><i class='bx bx-check'></i> Informazioni non disponibili</li>"

      const logoSrc = esperienza.logo || "/placeholder.svg?height=64&width=64"

      card.innerHTML = `
        <div class="experience-header">
          <div class="company-logo">
            <img class="azienda" src="${logoSrc}" alt="Logo ${
              esperienza.azienda
            }" onerror="this.src='/placeholder.svg?height=64&width=64'; this.onerror=null;" />
          </div>
          <div class="company-info">
            <h4>${esperienza.azienda || "Azienda non specificata"}</h4>
            <div class="role-badge">${esperienza.ruolo || "Ruolo non specificato"}</div>
          </div>
        </div>
        <div class="experience-period">
          <i class='bx bx-calendar'></i>
          <span>${esperienza.periodo || "Periodo non specificato"}</span>
        </div>
        <div class="experience-location">
          <i class='bx bx-map'></i>
          <span>${esperienza.luogo || "Luogo non specificato"}</span>
        </div>
        <div class="experience-activities">
          <h5>Attività svolte:</h5>
          <ul class="activities-list">
            ${attivitaList}
          </ul>
        </div>
        ${
          esperienza.sito
            ? `
          <button class="go-live-btn" onclick="window.open('${esperienza.sito}', '_blank')">
            <span>Visita il sito</span>
            <i class='bx bx-link-external'></i>
          </button>
        `
            : ""
        }
      `

      cardsContainer.appendChild(card)
    })
  }

  const applyEsperienzeFilters = () => {
    let filtered = esperienze

    if (activeRoles.size > 0) {
      filtered = filtered.filter((item) => activeRoles.has((item.ruolo || "").trim()))
    }

    filtered = filtered.filter((item) => isItemInMonthRange(item, fromMonthValue, toMonthValue))

    const normalizedSearch = searchTerm.trim().toLowerCase()
    if (normalizedSearch) {
      filtered = filtered.filter((item) => {
        const azienda = (item?.azienda || "").toLowerCase()
        const ruolo = (item?.ruolo || "").toLowerCase()
        const luogo = (item?.luogo || "").toLowerCase()
        const periodo = (item?.periodo || "").toLowerCase()
        const attivita = Array.isArray(item?.attivita) ? item.attivita.join(" ").toLowerCase() : ""

        return (
          azienda.includes(normalizedSearch) ||
          ruolo.includes(normalizedSearch) ||
          luogo.includes(normalizedSearch) ||
          periodo.includes(normalizedSearch) ||
          attivita.includes(normalizedSearch)
        )
      })
    }

    cardsContainer.classList.add("fade-out")
    setTimeout(() => {
      renderEsperienzeCards(filtered)
      cardsContainer.classList.remove("fade-out")
      cardsContainer.scrollTop = 0
    }, 250)
  }

  const updateActiveTabs = () => {
    tabsContainer.querySelectorAll(".skill-tab").forEach((tab) => {
      const tabFilter = tab.getAttribute("data-filter")
      tab.classList.toggle("active", tabFilter === "Tutti" ? activeRoles.size === 0 : activeRoles.has(tabFilter))
    })
  }

  buildFilterSelect(tabsContainer, filters, activeRoles, applyEsperienzeFilters)

  yearsBar.innerHTML = `
    <label>
      <span>Da</span>
      <input type="text" class="year-input year-from" placeholder="${formatMonthYearValue(minMonthValue)}" inputmode="numeric" />
      <button type="button" class="year-ok-btn">OK</button>
    </label>
    <label>
      <span>A</span>
      <input type="text" class="year-input year-to" placeholder="${formatMonthYearValue(maxMonthValue)}" inputmode="numeric" />
      <button type="button" class="year-ok-btn">OK</button>
    </label>
    <button type="button" class="year-reset-btn">Reset</button>
  `

  const fromInput = yearsBar.querySelector(".year-from")
  const toInput = yearsBar.querySelector(".year-to")
  const okButtons = yearsBar.querySelectorAll(".year-ok-btn")
  const resetButton = yearsBar.querySelector(".year-reset-btn")

  const handleMonthYearTyping = (event) => {
    event.target.value = normalizeMonthYearTyping(event.target.value)
  }

  const updateYears = () => {
    fromMonthValue = parseMonthYearInput(fromInput.value)
    toMonthValue = parseMonthYearInput(toInput.value)

    if (fromInput.value.trim() && fromMonthValue === null) {
      fromInput.value = ""
    } else if (fromMonthValue !== null) {
      fromInput.value = formatMonthYearValue(fromMonthValue)
    }

    if (toInput.value.trim() && toMonthValue === null) {
      toInput.value = ""
    } else if (toMonthValue !== null) {
      toInput.value = formatMonthYearValue(toMonthValue)
    }

    if (fromMonthValue !== null && toMonthValue !== null && fromMonthValue > toMonthValue) {
      const temp = fromMonthValue
      fromMonthValue = toMonthValue
      toMonthValue = temp
      fromInput.value = formatMonthYearValue(fromMonthValue)
      toInput.value = formatMonthYearValue(toMonthValue)
    }

    applyEsperienzeFilters()
  }

  okButtons.forEach((btn) => {
    btn.addEventListener("click", updateYears)
  })

  fromInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") updateYears()
  })
  fromInput.addEventListener("input", handleMonthYearTyping)

  toInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") updateYears()
  })
  toInput.addEventListener("input", handleMonthYearTyping)

  resetButton.addEventListener("click", () => {
    fromInput.value = ""
    toInput.value = ""
    fromMonthValue = null
    toMonthValue = null
    applyEsperienzeFilters()
  })

  searchBar.innerHTML = `
    <label>
      <span>Cerca</span>
      <input
        type="search"
        class="year-input esperienze-search-input"
        placeholder="Es. azienda, ruolo, luogo..."
      />
    </label>
    <button type="button" class="year-reset-btn esperienze-search-reset">Reset</button>
  `

  const esperienzeSearchInput = searchBar.querySelector(".esperienze-search-input")
  const esperienzeSearchReset = searchBar.querySelector(".esperienze-search-reset")

  const updateEsperienzeSearch = () => {
    searchTerm = esperienzeSearchInput.value || ""
    applyEsperienzeFilters()
  }

  esperienzeSearchInput.addEventListener("input", updateEsperienzeSearch)
  esperienzeSearchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault()
      updateEsperienzeSearch()
    }
  })

  esperienzeSearchReset.addEventListener("click", () => {
    esperienzeSearchInput.value = ""
    searchTerm = ""
    applyEsperienzeFilters()
  })

  const esperienzeStickyControls = document.createElement("div")
  esperienzeStickyControls.className = "skills-sticky-controls"
  esperienzeStickyControls.appendChild(tabsContainer)
  esperienzeStickyControls.appendChild(yearsBar)
  esperienzeStickyControls.appendChild(searchBar)

  DOM.sections.esperienze.appendChild(esperienzeStickyControls)
  DOM.sections.esperienze.appendChild(cardsContainer)
  updateActiveTabs()
  renderEsperienzeCards(esperienze)
}

/**
 * Render competenze section with improved mobile experience
 */
function renderCompetenze(competenze) {
  if (!competenze || !Array.isArray(competenze) || !DOM.sections.competenze) {
    console.warn("Curriculum.js: Invalid competenze data or container not found")
    return
  }

  DOM.sections.competenze.innerHTML = ""

  // Create tabs for categories
  const tabsContainer = document.createElement("div")
  tabsContainer.className = "skills-tabs"

  // Create container for skill cards
  const skillsContainer = document.createElement("div")
  skillsContainer.className = "skills-container"

  // Sticky wrapper to keep category filters + search fixed while scrolling
  const stickyControls = document.createElement("div")
  stickyControls.className = "skills-sticky-controls"

  // Create search bar using the same visual style of year filters
  const searchBar = document.createElement("div")
  searchBar.className = "year-filter-bar"

  // Ordina le categorie in ordine alfabetico
  const sortedCategories = Object.keys(STATE.categorizedSkills).sort((a, b) => {
    return a.localeCompare(b, 'it')
  })
  const categoriesWithAll = ["Tutti", ...sortedCategories]
  let activeCategories = new Set()
  let searchTerm = ""

  const getCategoryItems = () => {
    if (activeCategories.size === 0) return competenze

    const selectedItems = [...activeCategories].flatMap((category) => STATE.categorizedSkills[category] || [])
    const uniqueByName = new Map()
    selectedItems.forEach((item) => {
      if (item?.nome && !uniqueByName.has(item.nome)) {
        uniqueByName.set(item.nome, item)
      }
    })
    return [...uniqueByName.values()]
  }

  const applyCompetenzeFilters = () => {
    const normalizedSearch = searchTerm.trim().toLowerCase()
    let filtered = getCategoryItems()

    if (normalizedSearch) {
      filtered = filtered.filter((skill) => {
        const name = (skill?.nome || "").toLowerCase()
        const description = (skill?.descrizione || "").toLowerCase()
        const category = getSkillCategoryLabel(skill).toLowerCase()

        return (
          name.includes(normalizedSearch) ||
          description.includes(normalizedSearch) ||
          category.includes(normalizedSearch)
        )
      })
    }

    skillsContainer.classList.add("fade-out")
    setTimeout(() => {
      renderSkillCategory(filtered, skillsContainer, activeCategories.size !== 1)
      skillsContainer.classList.remove("fade-out")

      // Initialize progress bar animations
      setTimeout(() => {
        initializeSkillAnimations()
      }, 100)
    }, 250)
  }

  const updateActiveTabs = () => {
    tabsContainer.querySelectorAll(".skill-tab").forEach((tab) => {
      const tabCategory = tab.getAttribute("data-category")
      tab.classList.toggle("active", tabCategory === "Tutti" ? activeCategories.size === 0 : activeCategories.has(tabCategory))
    })
  }

  buildFilterSelect(tabsContainer, categoriesWithAll, activeCategories, applyCompetenzeFilters)

  searchBar.innerHTML = `
    <label>
      <span>Cerca</span>
      <input
        type="search"
        class="year-input skill-search-input"
        placeholder="Es. JavaScript, Docker, Frontend..."
      />
    </label>
    <button type="button" class="year-reset-btn skill-search-reset">Reset</button>
  `

  const searchInput = searchBar.querySelector(".skill-search-input")
  const searchResetButton = searchBar.querySelector(".skill-search-reset")

  const updateSearch = () => {
    searchTerm = searchInput.value || ""
    applyCompetenzeFilters()
  }

  searchInput.addEventListener("input", updateSearch)
  searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault()
      updateSearch()
    }
  })

  searchResetButton.addEventListener("click", () => {
    searchInput.value = ""
    searchTerm = ""
    applyCompetenzeFilters()
  })

  stickyControls.appendChild(tabsContainer)
  stickyControls.appendChild(searchBar)

  DOM.sections.competenze.appendChild(stickyControls)
  DOM.sections.competenze.appendChild(skillsContainer)

  // Show "Tutti" by default
  updateActiveTabs()
  applyCompetenzeFilters()
}

/**
 * Render skills for a specific category with improved layout
 */
function renderSkillCategory(skills, container, showCategory = false) {
  if (!container) return

  container.innerHTML = ""

  if (!skills || !Array.isArray(skills) || skills.length === 0) {
    container.innerHTML = `
      <div class="empty-category">
        <i class='bx bx-info-circle'></i>
        <p>Nessuna competenza in questa categoria.</p>
      </div>
    `
    return
  }

  // Ordina le competenze in ordine alfabetico per nome
  const sortedSkills = [...skills].sort((a, b) => {
    const nameA = (a.nome || "").toLowerCase()
    const nameB = (b.nome || "").toLowerCase()
    return nameA.localeCompare(nameB, 'it')
  })

  sortedSkills.forEach((skill, index) => {
    const card = document.createElement("div")
    card.className = "card skill-card"
    card.setAttribute("data-aos", "zoom-in")
    card.setAttribute("data-aos-delay", (index * 50).toString())

    // Generate random color for progress bar
    const hue = Math.floor(Math.random() * 360)
    const progressColor = `hsl(${hue}, 70%, 60%)`

    // Handle potential missing image
    const imgSrc = skill.immagine || "/placeholder.svg?height=80&width=80"

    card.innerHTML = `
      <div class="skill-icon" style="background-color: ${progressColor}20;">
        <img src="${imgSrc}" alt="${
          skill.nome
        }" onerror="this.src='/placeholder.svg?height=80&width=80'; this.onerror=null;" />
      </div>
      <h4>${skill.nome || "Competenza non specificata"}</h4>
      ${
        showCategory
          ? `<div class="skill-category-badge">${getSkillCategoryLabel(skill)}</div>`
          : ""
      }
      <div class="skill-progress">
        <div class="progress-bar" data-progress="85" style="--progress-color: ${progressColor};">
          <div class="progress-fill"></div>
        </div>
      </div>
      <p>${skill.descrizione || "Descrizione non disponibile"}</p>
      ${
        skill.link
          ? `
        <button class="go-live-btn" onclick="window.open('${skill.link}', '_blank')">
          <span>Scopri di più</span>
          <i class='bx bx-link-external'></i>
        </button>
      `
          : ""
      }
    `

    container.appendChild(card)
  })
}

/**
 * Render siti web section with mobile optimizations
 */
function renderWebSite(sites) {
  if (!sites || !Array.isArray(sites) || !DOM.sections.sites) {
    console.warn("Curriculum.js: Invalid sites data or container not found")
    return
  }

  DOM.sections.sites.innerHTML = ""
  DOM.sections.sites.className = "card-container"

  const stickyControls = document.createElement("div")
  stickyControls.className = "skills-sticky-controls"

  const searchBar = document.createElement("div")
  searchBar.className = "year-filter-bar"

  const cardsContainer = document.createElement("div")
  cardsContainer.className = "sites-list"

  let searchTerm = ""

  const renderSitesCards = (items) => {
    cardsContainer.innerHTML = ""

    if (!items || items.length === 0) {
      cardsContainer.innerHTML = `
        <div class="empty-filter-message">
          <i class='bx bx-info-circle'></i>
          <p>Non ci sono siti per questi criteri.</p>
        </div>
      `
      return
    }

    items.forEach((site, index) => {
      const card = document.createElement("div")
      card.className = "card portfolio-card"
      card.setAttribute("data-aos", "fade-up")
      card.setAttribute("data-aos-delay", (index * 100).toString())

      const imgSrc = site.immagine || "/placeholder.svg?height=200&width=300"
      const imageHeight = STATE.isMobile ? CONFIG.siteImageMaxHeight : 200

      const html = `
        <div class="portfolio-image" style="height: ${imageHeight}px;">
          <img src="${imgSrc}" alt="${site.nome}" class="site-image" 
               style="max-height: ${imageHeight}px;" 
               onerror="this.src='/placeholder.svg?height=${imageHeight}&width=${
                 imageHeight * 1.5
               }'; this.onerror=null;" />
          <div class="portfolio-overlay">
            <div class="portfolio-buttons">
              ${
                site.link
                  ? `
                <a href="${site.link}" target="_blank" class="portfolio-btn view-btn">
                  <i class='bx bx-link-external'></i>
                  <span class="white">Visita</span>
                </a>
              `
                  : ""
              }
              ${
                site.codice
                  ? `
                <a href="${site.codice}" target="_blank" class="portfolio-btn code-btn">
                  <i class='bx bx-code-alt'></i>
                  <span class="white">Codice</span>
                </a>
              `
                  : ""
              }
            </div>
          </div>
        </div>
        <div class="portfolio-info">
          <h4>${site.nome || "Progetto non specificato"}</h4>
          <div class="portfolio-tags">
            ${generateProjectTags()}
          </div>
        </div>
      `

      card.innerHTML = html
      cardsContainer.appendChild(card)
    })
  }

  const applySitesFilters = () => {
    const normalizedSearch = searchTerm.trim().toLowerCase()
    let filtered = sites

    if (normalizedSearch) {
      filtered = filtered.filter((site) => {
        const name = (site?.nome || "").toLowerCase()
        const link = (site?.link || "").toLowerCase()
        const code = (site?.codice || "").toLowerCase()
        return name.includes(normalizedSearch) || link.includes(normalizedSearch) || code.includes(normalizedSearch)
      })
    }

    cardsContainer.classList.add("fade-out")
    setTimeout(() => {
      renderSitesCards(filtered)
      cardsContainer.classList.remove("fade-out")
      cardsContainer.scrollTop = 0
    }, 250)
  }

  searchBar.innerHTML = `
    <label>
      <span>Cerca</span>
      <input
        type="search"
        class="year-input sites-search-input"
        placeholder="Es. portfolio, github, ecommerce..."
      />
    </label>
    <button type="button" class="year-reset-btn sites-search-reset">Reset</button>
  `

  const searchInput = searchBar.querySelector(".sites-search-input")
  const searchResetButton = searchBar.querySelector(".sites-search-reset")

  const updateSearch = () => {
    searchTerm = searchInput.value || ""
    applySitesFilters()
  }

  searchInput.addEventListener("input", updateSearch)
  searchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault()
      updateSearch()
    }
  })

  searchResetButton.addEventListener("click", () => {
    searchInput.value = ""
    searchTerm = ""
    applySitesFilters()
  })

  stickyControls.appendChild(searchBar)
  DOM.sections.sites.appendChild(stickyControls)
  DOM.sections.sites.appendChild(cardsContainer)
  applySitesFilters()
}

/**
 * Generate tags for projects using the default project tags from categories.json
 */
function generateProjectTags() {
  // Use default tags from categories.json if available
  let defaultTags = ["HTML", "CSS", "JavaScript", "Responsive", "Frontend", "UI/UX"]

  if (STATE.categoriesData && STATE.categoriesData.defaultProjectTags) {
    defaultTags = STATE.categoriesData.defaultProjectTags
  }

  // Always include all tags as requested
  return defaultTags.map((tag) => `<span class="portfolio-tag">${tag}</span>`).join("")
}

/**
 * Get icon for skill category
 */
function getCategoryIcon(category) {
  const icons = {
    Programmazione: "bx-code-alt",
    "DevOps & Tools": "bx-wrench",
    "IoT & Protocolli": "bx-network-chart",
    Visualizzazione: "bx-bar-chart-alt-2",
    Frontend: "bx-layout",
    Backend: "bx-server",
    Database: "bx-data",
    Mobile: "bx-mobile-alt",
    Cloud: "bx-cloud",
    Security: "bx-shield-quarter",
    Altro: "bx-category",
  }

  return icons[category] || "bx-category"
}

/**
 * Categorize skills directly from JSON data
 * This function prioritizes the 'categoria' property in the JSON
 */
function categorizeSkillsFromJson(competenze) {
  if (!competenze || !Array.isArray(competenze)) {
    return {}
  }

  // First, collect all unique categories from the JSON data
  const uniqueCategories = new Set()
  competenze.forEach((skill) => {
    if (skill.categoria) {
      uniqueCategories.add(skill.categoria)
    }
  })

  // If no categories found in JSON, use default categorization
  if (uniqueCategories.size === 0) {
    return categorizeSkillsByName(competenze)
  }

  // Create categorized object based on JSON categories
  const categorized = {}

  // First, add skills with explicit categories
  uniqueCategories.forEach((category) => {
    categorized[category] = competenze.filter((skill) => skill.categoria === category)
  })

  // Then add any uncategorized skills to "Altro"
  const categorizedSkillIds = Object.values(categorized)
    .flat()
    .map((skill) => skill.nome)

  const uncategorizedSkills = competenze.filter(
    (skill) => !skill.categoria && !categorizedSkillIds.includes(skill.nome),
  )

  if (uncategorizedSkills.length > 0) {
    // Try to categorize remaining skills by name
    const remainingCategorized = categorizeSkillsByName(uncategorizedSkills)

    // Merge with existing categories
    Object.keys(remainingCategorized).forEach((category) => {
      if (categorized[category]) {
        categorized[category] = [...categorized[category], ...remainingCategorized[category]]
      } else {
        categorized[category] = remainingCategorized[category]
      }
    })
  }

  return categorized
}

/**
 * Fallback categorization by skill name
 */
function categorizeSkillsByName(competenze) {
  // Use categories from the loaded JSON if available
  let categories = {}

  if (STATE.categoriesData && STATE.categoriesData.skillCategories) {
    categories = STATE.categoriesData.skillCategories
  } else {
    // Fallback to hardcoded categories
    categories = {
      Programmazione: ["C", "C#", "C++", "Python", "JavaScript", "HTML5", "CSS3", "React JS", "Node.js", "Vite"],
      "DevOps & Tools": ["Git", "VS Code", "Docker", "PostgreSQL", "Linux", "Windows"],
      "IoT & Protocolli": ["MQTT", "AMQP", "CoAP", "HTTP", "OPC-UA", "Raspberry Pi", "Node-RED"],
      Visualizzazione: ["Mermaid", "Chart.js", "MathJax"],
    }
  }

  const categorized = {}

  // Categorize based on predefined categories
  Object.keys(categories).forEach((category) => {
    categorized[category] = competenze.filter((skill) => categories[category].includes(skill.nome))
  })

  // Add "Altro" category for uncategorized skills
  const categorizedSkillNames = Object.values(categorized)
    .flat()
    .map((skill) => skill.nome)

  const otherSkills = competenze.filter((skill) => !categorizedSkillNames.includes(skill.nome))

  if (otherSkills.length > 0) {
    categorized["Altro"] = otherSkills
  }

  return categorized
}

/**
 * Generate fallback data in case of loading failure
 */
function generateFallbackData() {
  console.log("Curriculum.js: Generating fallback data")
  return {
    attestati: [
      {
        titolo: "Esempio Attestato",
        descrizione: "Questo è un esempio di attestato generato come fallback.",
        certificato: "",
      },
    ],
    linguistiche: [
      {
        lingua: "Inglese",
        livello: "B1",
        immagine: "/placeholder.svg?height=100&width=100",
        link: "#",
      },
    ],
    esperienze: [
      {
        azienda: "Azienda Esempio",
        ruolo: "Sviluppatore",
        periodo: "2023 - Presente",
        luogo: "Italia",
        attivita: ["Sviluppo web", "Programmazione"],
        logo: "/placeholder.svg?height=64&width=64",
        sito: "#",
      },
    ],
    istruzione: [
      {
        titolo: "Laurea in Informatica",
        istituto: "Università",
        periodo: "2020 - 2023",
        luogo: "Italia",
        logo: "/placeholder.svg?height=64&width=64",
        sito: "#",
      },
    ],
    competenze: [
      {
        nome: "HTML",
        descrizione: "Competenze in HTML",
        immagine: "/placeholder.svg?height=64&width=64",
        link: "#",
        categoria: "Frontend",
      },
      {
        nome: "CSS",
        descrizione: "Competenze in CSS",
        immagine: "/placeholder.svg?height=64&width=64",
        link: "#",
        categoria: "Frontend",
      },
      {
        nome: "JavaScript",
        descrizione: "Competenze in JavaScript",
        immagine: "/placeholder.svg?height=64&width=64",
        link: "#",
        categoria: "Frontend",
      },
    ],
    sites: [
      {
        nome: "Portfolio",
        immagine: "/placeholder.svg?height=200&width=300",
        link: "#",
        codice: "#",
      },
    ],
  }
}

/**
 * Render istruzione section
 */
function renderIstruzione(istruzione) {
  if (!istruzione || !Array.isArray(istruzione) || !DOM.sections.istruzione) {
    console.warn("Curriculum.js: Invalid istruzione data or container not found");
    return;
  }

  DOM.sections.istruzione.innerHTML = "";

  const livelli = [...new Set(istruzione.map((item) => (item.livello || "").trim()).filter(Boolean))]
  const filters = ["Tutti", ...livelli];

  const tabsContainer = document.createElement("div");
  tabsContainer.className = "skills-tabs";

  const yearsBar = document.createElement("div");
  yearsBar.className = "year-filter-bar";
  const searchBar = document.createElement("div");
  searchBar.className = "year-filter-bar";

  const cardsContainer = document.createElement("div");
  cardsContainer.className = "istruzione-list";

  const availableMonthValues = istruzione
    .map((item) => getItemMonthSpan(item))
    .filter(Boolean)
    .flatMap((span) => [span.startValue, span.endValue])

  const now = new Date()
  const fallbackMonthValue = monthYearToValue(now.getMonth() + 1, now.getFullYear())
  const minMonthValue = availableMonthValues.length ? Math.min(...availableMonthValues) : fallbackMonthValue
  const maxMonthValue = availableMonthValues.length ? Math.max(...availableMonthValues) : fallbackMonthValue

  let activeLevels = new Set();
  let fromMonthValue = null;
  let toMonthValue = null;
  let searchTerm = "";

  const renderIstruzioneCards = (items) => {
    cardsContainer.innerHTML = "";

    if (!items || items.length === 0) {
      cardsContainer.innerHTML = `
        <div class="empty-filter-message">
          <i class='bx bx-info-circle'></i>
          <p>Non ci sono dati per questi criteri.</p>
        </div>
      `;
      return;
    }

    items.forEach((item, index) => {
      const card = document.createElement("div");
      card.className = "card istruzione-card";
      card.setAttribute("data-aos", "fade-up");
      card.setAttribute("data-aos-delay", (index * 100).toString());

      const logoSrc = item.logo || "/placeholder.svg?height=64&width=64";

      let competenzeHtml = "";
      if (Array.isArray(item.competenze)) {
        competenzeHtml = `
          <ul class="competenze">
            ${item.competenze.map(comp => `<li>${comp}</li>`).join("")}
          </ul>
        `;
      } else if (item.descrizione) {
        competenzeHtml = `<p class="descrizione">${item.descrizione}</p>`;
      }

      const downloadButton = item.diploma
        ? `<a href="${item.diploma}" class="go-live-btn" download>
            <span>Scarica diploma</span>
            <i class='bx bx-download'></i>
          </a>`
        : "";

      const siteButton = item.sito
        ? `<button class="go-live-btn" onclick="window.open('${item.sito}', '_blank')">
            <span>Visita il sito</span>
            <i class='bx bx-link-external'></i>
          </button>`
        : "";

      card.innerHTML = `
        <div class="istruzione-header">
          <div class="istituto-logo">
            <img class="azienda" src="${logoSrc}" alt="Logo ${item.istituto}" 
                 onerror="this.src='/placeholder.svg?height=64&width=64'; this.onerror=null;" />
          </div>
          <div class="istituto-info">
            <h4>${item.titolo || "Titolo non specificato"}</h4>
            <div>${item.istituto || "Istituto non specificato"}</div>
            <div class="livello-eqf">${item.livello || ""}</div>
          </div>
        </div>
        <div class="istruzione-period">
          <i class='bx bx-calendar'></i>
          <span>${item.periodo || "Periodo non specificato"}</span>
        </div>
        <div class="istruzione-location">
          <i class='bx bx-map'></i>
          <span>${item.luogo || "Luogo non specificato"}</span>
        </div>
        ${competenzeHtml}
        <div class="istruzione-buttons">
          ${siteButton}
          ${downloadButton}
        </div>
      `;

      cardsContainer.appendChild(card);
    });
  };

  const applyIstruzioneFilters = () => {
    let filtered = istruzione;

    if (activeLevels.size > 0) {
      filtered = filtered.filter((item) => activeLevels.has((item.livello || "").trim()));
    }

    filtered = filtered.filter((item) => isItemInMonthRange(item, fromMonthValue, toMonthValue));

    const normalizedSearch = searchTerm.trim().toLowerCase();
    if (normalizedSearch) {
      filtered = filtered.filter((item) => {
        const titolo = (item?.titolo || "").toLowerCase();
        const istituto = (item?.istituto || "").toLowerCase();
        const livello = (item?.livello || "").toLowerCase();
        const luogo = (item?.luogo || "").toLowerCase();
        const periodo = (item?.periodo || "").toLowerCase();
        const descrizione = (item?.descrizione || "").toLowerCase();
        const competenze = Array.isArray(item?.competenze) ? item.competenze.join(" ").toLowerCase() : "";

        return (
          titolo.includes(normalizedSearch) ||
          istituto.includes(normalizedSearch) ||
          livello.includes(normalizedSearch) ||
          luogo.includes(normalizedSearch) ||
          periodo.includes(normalizedSearch) ||
          descrizione.includes(normalizedSearch) ||
          competenze.includes(normalizedSearch)
        );
      });
    }

    cardsContainer.classList.add("fade-out");
    setTimeout(() => {
      renderIstruzioneCards(filtered);
      cardsContainer.classList.remove("fade-out");
      cardsContainer.scrollTop = 0;
    }, 250);
  };

  const updateActiveTabs = () => {
    tabsContainer.querySelectorAll(".skill-tab").forEach((tab) => {
      const tabFilter = tab.getAttribute("data-filter");
      tab.classList.toggle("active", tabFilter === "Tutti" ? activeLevels.size === 0 : activeLevels.has(tabFilter));
    });
  };

  buildFilterSelect(tabsContainer, filters, activeLevels, applyIstruzioneFilters);

  yearsBar.innerHTML = `
    <label>
      <span>Da</span>
      <input type="text" class="year-input year-from" placeholder="${formatMonthYearValue(minMonthValue)}" inputmode="numeric" />
      <button type="button" class="year-ok-btn">OK</button>
    </label>
    <label>
      <span>A</span>
      <input type="text" class="year-input year-to" placeholder="${formatMonthYearValue(maxMonthValue)}" inputmode="numeric" />
      <button type="button" class="year-ok-btn">OK</button>
    </label>
    <button type="button" class="year-reset-btn">Reset</button>
  `;

  const fromInput = yearsBar.querySelector(".year-from");
  const toInput = yearsBar.querySelector(".year-to");
  const okButtons = yearsBar.querySelectorAll(".year-ok-btn");
  const resetButton = yearsBar.querySelector(".year-reset-btn");

  const handleMonthYearTyping = (event) => {
    event.target.value = normalizeMonthYearTyping(event.target.value);
  };

  const updateYears = () => {
    fromMonthValue = parseMonthYearInput(fromInput.value);
    toMonthValue = parseMonthYearInput(toInput.value);

    if (fromInput.value.trim() && fromMonthValue === null) {
      fromInput.value = "";
    } else if (fromMonthValue !== null) {
      fromInput.value = formatMonthYearValue(fromMonthValue);
    }

    if (toInput.value.trim() && toMonthValue === null) {
      toInput.value = "";
    } else if (toMonthValue !== null) {
      toInput.value = formatMonthYearValue(toMonthValue);
    }

    if (fromMonthValue !== null && toMonthValue !== null && fromMonthValue > toMonthValue) {
      const temp = fromMonthValue;
      fromMonthValue = toMonthValue;
      toMonthValue = temp;
      fromInput.value = formatMonthYearValue(fromMonthValue);
      toInput.value = formatMonthYearValue(toMonthValue);
    }

    applyIstruzioneFilters();
  };

  okButtons.forEach((btn) => {
    btn.addEventListener("click", updateYears);
  });

  fromInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") updateYears();
  });
  fromInput.addEventListener("input", handleMonthYearTyping);

  toInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") updateYears();
  });
  toInput.addEventListener("input", handleMonthYearTyping);

  resetButton.addEventListener("click", () => {
    fromInput.value = "";
    toInput.value = "";
    fromMonthValue = null;
    toMonthValue = null;
    applyIstruzioneFilters();
  });

  searchBar.innerHTML = `
    <label>
      <span>Cerca</span>
      <input
        type="search"
        class="year-input istruzione-search-input"
        placeholder="Es. diploma, istituto, livello..."
      />
    </label>
    <button type="button" class="year-reset-btn istruzione-search-reset">Reset</button>
  `;

  const istruzioneSearchInput = searchBar.querySelector(".istruzione-search-input");
  const istruzioneSearchReset = searchBar.querySelector(".istruzione-search-reset");

  const updateIstruzioneSearch = () => {
    searchTerm = istruzioneSearchInput.value || "";
    applyIstruzioneFilters();
  };

  istruzioneSearchInput.addEventListener("input", updateIstruzioneSearch);
  istruzioneSearchInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      updateIstruzioneSearch();
    }
  });

  istruzioneSearchReset.addEventListener("click", () => {
    istruzioneSearchInput.value = "";
    searchTerm = "";
    applyIstruzioneFilters();
  });

  const istruzioneStickyControls = document.createElement("div");
  istruzioneStickyControls.className = "skills-sticky-controls";
  istruzioneStickyControls.appendChild(tabsContainer);
  istruzioneStickyControls.appendChild(yearsBar);
  istruzioneStickyControls.appendChild(searchBar);

  DOM.sections.istruzione.appendChild(istruzioneStickyControls);
  DOM.sections.istruzione.appendChild(cardsContainer);
  updateActiveTabs();
  renderIstruzioneCards(istruzione);
}